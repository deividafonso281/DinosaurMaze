public interface ICenario {
	public void setVisible(boolean vis);
	public void setObstacle(boolean obs);
	public boolean getObstacle();
	public boolean getVisible();
}
