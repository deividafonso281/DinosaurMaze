public interface ITabuleiro {
	public void startGame();
	public void endGame();
	public void doOneLoop();
}
