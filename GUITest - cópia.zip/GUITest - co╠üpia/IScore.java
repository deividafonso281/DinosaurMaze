import java.math.*;
public interface IScore {
	public BigInteger increment();
}
